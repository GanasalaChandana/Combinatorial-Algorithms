# Define the Union-Find data structure
class UnionFind:
    def __init__(self):
        # Initialize a dictionary to store the parent of each element (set).
        self.parent = {}
    
    def find(self, u):
        # Find the representative (root) of the set that 'u' belongs to.
        if u != self.parent.setdefault(u, u):
            # Use path compression by recursively finding the root and updating the parent.
            self.parent[u] = self.find(self.parent[u])
        return self.parent[u]
    
    def union(self, u, v):
        # Union two sets represented by 'u' and 'v'.
        pu, pv = self.find(u), self.find(v)
        if pu != pv:
            # Set the parent of one representative to the other, effectively merging the sets.
            self.parent[pu] = pv

# Define the Kruskal's algorithm to find the Minimum Spanning Tree (MST)
def kruskal(graph):
    edges = []
    # Create a list of all edges in the graph with their weights.
    for u, neighbors in graph.items():
        for v, weight in neighbors.items():
            edges.append((u, v, weight))
    
    # Sort edges by weight in descending order, with tie-breaking by node names.
    edges.sort(key=lambda x: (x[2], x[0], x[1]))
    
    mst_edges = set()  # Initialize an empty set to store the MST edges.
    uf = UnionFind()   # Create an instance of the Union-Find data structure.
    
    # Iterate through the sorted edges and build the MST.
    for u, v, weight in edges:
        if uf.find(u) != uf.find(v):
            # If 'u' and 'v' are not in the same set, adding this edge won't create a cycle.
            mst_edges.add((u, v, weight))
            uf.union(u, v)  # Union the sets containing 'u' and 'v'.
    
    return mst_edges

# Define the given graph with edge weights
graph = {
    'a': {'b': 10, 'e': 5, 'd': 10},
    'b': {'a': 10, 'c': 9},
    'c': {'b': 9, 'g': 9, 'd': 10},
    'd': {'a': 10, 'c': 10, 'e': 10, 'g': 10},
    'e': {'a': 5, 'd': 10, 'h': 10},
    'f': {'h': 10},
    'g': {'c': 9, 'd': 10, 'h': 9},
    'h': {'e': 10, 'f': 10, 'g': 9}
}

# Find the Minimum Spanning Tree using Kruskal's algorithm
mst = kruskal(graph)

# Print the MST edges and their weights
for u, v, weight in mst:
    print(f"Edge: {u} - {v}, Weight: {weight}")
