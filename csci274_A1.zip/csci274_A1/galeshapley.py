# Function to perform the Gale-Shapley algorithm to find a stable matching
def gale_shapley_stable_matching(men_pref, women_pref):
    n = len(men_pref)
    men = list(range(n))
    women = list(range(n))
    men_matched = [-1] * n
    women_matched = [-1] * n
    
    while men:
        m = men.pop(0)
        w_pref = men_pref[m]
        
        for w in w_pref:
            if women_matched[w - 1] == -1:
                men_matched[m] = w
                women_matched[w - 1] = m
                break
            else:
                m_prime = women_matched[w - 1]
                w_pref = women_pref[w - 1]
                if w_pref.index(m + 1) < w_pref.index(m_prime + 1):  # Adjust indexing here
                    men_matched[m] = w
                    men_matched[m_prime] = -1
                    men.append(m_prime)
                    women_matched[w - 1] = m
                    break
    
    matching = [(i + 1, men_matched[i]) for i in range(n)]
    return matching

# Men's preference lists
men_pref = [
    [1, 6, 5, 2, 4, 3, 7], 
    [1, 4, 3, 2, 7, 6, 5], 
    [7, 6, 5, 1, 2, 4, 3],  
    [4, 3, 1, 2, 5, 7, 6],  
    [3, 2, 1, 4, 5, 6, 7],  
    [7, 6, 5, 4, 3, 2, 1],  
    [6, 7, 4, 5, 3, 2, 1]   
]

# Women's preference lists
women_pref = [
    [2, 6, 5, 1, 4, 3, 7], 
    [1, 2, 5, 4, 3, 6, 7],  
    [5, 3, 1, 2, 4, 7, 6], 
    [4, 3, 1, 2, 5, 7, 6],  
    [2, 3, 4, 1, 7, 6, 5],  
    [7, 6, 5, 1, 2, 4, 3],  
    [6, 5, 4, 7, 3, 2, 1]   
]

# Find the stable matching using Gale-Shapley algorithm
matching = gale_shapley_stable_matching(men_pref, women_pref)

# Print the stable matching or a message if no stable matching is found
if matching is not None:
    print("Stable Matching:")
    for man, woman in matching:
        print(f"Man {man} is paired with Woman {woman}")
else:
    print("No stable matching.")
