size = -1

def swapping(heap, i, j):
    temp = heap[i]
    heap[i] = heap[j]
    heap[j] = temp

def insert(heap, a):
    # Method to add an element
    global size
    size = size + 1  # Increase the size of the heap
    heap[size] = a  # Assign the new value at the corresponding size of the heap index (at the bottom of heap)
    HeapifyUp(heap, size)  # Heaping up to rearrange the tree

def HeapifyUp(heap, i):
    # while (i > 0 and heap(getParent[i] > heap[i])): #Flipping the condition to greater than will give a minimum heap
    while i > 0 and heap[getParent(i)] < heap[i]:  # loop till the parent and also check if the parent is less than the child
        swapping(heap, getParent(i), i)  # In a max heap, the parent should always be greater than the child, so swap parent and child
        i = getParent(i)  # Make the current node parent to check further

def getParent(i):
    return (i - 1) // 2

def getMaximum(heap):
    return heap[0]

def Leftchild(i):
    return (2 * i) + 1

def Rightchild(i):
    return (2 * i) + 2

def HeapifyDown(heap, i):
    MaxInd = i
    # pick the side (Left or right) whose value is greater than MaxInd
    l = Leftchild(i)
    # if (l <= size and heap[l] < heap[MaxInd]): #Flipping the condition to less than will give a minimum heap
    if l <= size and heap[l] > heap[MaxInd]:
        MaxInd = l
    r = Rightchild(i)
    # if (r <= size and heap[r] < heap[MaxInd]):  #Flipping the condition to less than will give a minimum heap
    if r <= size and heap[r] > heap[MaxInd]:
        MaxInd = r
    # skip the same index
    if i != MaxInd:
        # swap the max index and the current element
        swapping(heap, i, MaxInd)
        # recursively recall the heap with MaxInd
        HeapifyDown(heap, MaxInd)

def Removemax(heap):
    # as the first element will be the highest and that will be extracted
    global size
    heap[0] = heap[size]  # replace the max element (first) with the last element
    size = size - 1  # decrease the size of the heap
    HeapifyDown(heap, 0)  # perform Heapify Down

def Remove(heap, i):
    # remove the element at a given index
    heap[i] = getMaximum(heap) + 1  # increase the current maximum value and place it at the index to remove
    # print (heap[i])
    HeapifyUp(heap, i)  # Heapify the heap so that the max element reaches the top, and it will be the root
    Removemax(heap)

def printHeap(heap, size):
    for i in range(0, size + 1):
        print(heap[i], end=" ")
    print()

# Initiating the heap with 40 size and default values as 0.
heap = [0] * 40

# Inserting elements into the heap
insert(heap, 35)
insert(heap, 20)
insert(heap, 10)
insert(heap, 12)
insert(heap, 21)
printHeap(heap, size)

Remove(heap, 0)
printHeap(heap, size)
Remove(heap, 1)
printHeap(heap, size)
Remove(heap, 2)
printHeap(heap, size)
Remove(heap, 1)
printHeap(heap, size)
Remove(heap, 0)
printHeap(heap, size)
