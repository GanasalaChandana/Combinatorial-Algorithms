import itertools

# Function to check if a given set of pairings is stable
def is_stable(pairings, men_pref, women_pref):
    n = len(pairings)
    
    for i in range(n):
        man1, woman1 = pairings[i]
        for j in range(i + 1, n):
            man2, woman2 = pairings[j]
            
            # Check if the current pairings are unstable
            if (
                men_pref[man1-1].index(woman1) > men_pref[man1-1].index(woman2) and
                women_pref[woman2-1].index(man1) > women_pref[woman2-1].index(man2)
            ):
                return False
    return True

# Function to find a stable matching using brute-force
def brute_force_stable_matching(men_pref, women_pref):
    n = len(men_pref)
    men = list(range(1, n+1))
    best_matching = None

    # Generate all possible permutations of men's pairings
    for perm in itertools.permutations(range(1, n+1)):
        pairings = [(men[i-1], perm[i-1]) for i in men]
        
        # Check if the current permutation is stable
        if is_stable(pairings, men_pref, women_pref):
            best_matching = pairings

    return best_matching

# Men's preference lists
men_pref = [
    [1, 6, 5, 2, 4, 3, 7], 
    [1, 4, 3, 2, 7, 6, 5], 
    [7, 6, 5, 1, 2, 4, 3],  
    [4, 3, 1, 2, 5, 7, 6],  
    [3, 2, 1, 4, 5, 6, 7],  
    [7, 6, 5, 4, 3, 2, 1],  
    [6, 7, 4, 5, 3, 2, 1]   
]

# Women's preference lists
women_pref = [
    [2, 6, 5, 1, 4, 3, 7], 
    [1, 2, 5, 4, 3, 6, 7],  
    [5, 3, 1, 2, 4, 7, 6], 
    [4, 3, 1, 2, 5, 7, 6],  
    [2, 3, 4, 1, 7, 6, 5],  
    [7, 6, 5, 1, 2, 4, 3],  
    [6, 5, 4, 7, 3, 2, 1]   
]

# Find the stable matching using brute force
matching = brute_force_stable_matching(men_pref, women_pref)

# Print the stable matching
if matching is not None:
    print("Stable Matching:")
    for man, woman in matching:
        print(f"Man {man} is paired with Woman {woman}")
else:
    print("No stable matching.")
