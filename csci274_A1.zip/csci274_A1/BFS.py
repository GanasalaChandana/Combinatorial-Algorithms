def bfs(num_nodes, adjacency_matrix):
    visited = [False for _ in range(num_nodes)]  # Boolean array to maintain nodes that have been visited
    queue = []  # A queue for maintaining the indices
    queue.append(0)  # Adding the first element
    visited[0] = True  # Marking it as visited
    while len(queue) > 0:
        current_node = queue.pop(0)  # Taking the first element from the queue
        print(current_node)
        for neighbor in range(num_nodes):  # Loop through the columns for every element in the queue
            if adjacency_matrix[current_node][neighbor] == 1 and not visited[neighbor]:
                queue.append(neighbor)  # Add all the elements in the same level to the queue
                visited[neighbor] = True  # Mark all visited nodes

num_nodes = int(input("Enter the number of nodes: "))
adjacency_matrix = [[int(val) for val in input(f"Enter row {i + 1} of the adjacency matrix: ").strip().split()] for i in range(num_nodes)]
bfs(num_nodes, adjacency_matrix)
