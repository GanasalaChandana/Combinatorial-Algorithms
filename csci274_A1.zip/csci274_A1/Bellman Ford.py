class Graph:

    def __init__(self, vertices):
        self.V = vertices   # Total number of vertices in the graph
        self.edges = []     # List of edges

    # Add edges
    def add_edge(self, source, destination, weight):
        self.edges.append([source, destination, weight])

    # Print the solution
    def print_solution(self, distances):
        print("Vertex Distance from Source")
        for i in range(self.V):
            print("{0}\t\t{1}".format(i, distances[i]))

    def bellman_ford(self, source):

        # Step 1: Initialize the distance array
        distances = [float("Inf")] * self.V
        distances[source] = 0

        # Step 2: Relax edges V-1 times
        for _ in range(self.V - 1):
            for source_vertex, destination_vertex, weight in self.edges:
                if distances[source_vertex] != float("Inf") and distances[source_vertex] + weight < distances[destination_vertex]:
                    distances[destination_vertex] = distances[source_vertex] + weight

        # Step 3: Detect negative cycle
        for source_vertex, destination_vertex, weight in self.edges:
            if distances[source_vertex] != float("Inf") and distances[source_vertex] + weight < distances[destination_vertex]:
                print("Graph contains a negative weight cycle")
                return

        # No negative weight cycle found
        # Print the distance array
        self.print_solution(distances)


g = Graph(5)
g.add_edge(0, 1, 5)
g.add_edge(0, 2, 4)
g.add_edge(1, 3, 3)
g.add_edge(2, 1, 6)
g.add_edge(3, 2, 2)

g.bellman_ford(0)
