def topological_sort(graph):
    # Define a depth-first search function
    def dfs(node):
        # Mark the current node as visited
        visited.add(node)
        
        # Visit all neighbors of the current node
        for neighbor in graph[node]:
            if neighbor not in visited:
                dfs(neighbor)
        
        # Add the current node to the topological ordering
        topological_ordering.append(node)
    
    # Initialize a set to track visited nodes and a list for topological ordering
    visited = set()
    topological_ordering = []
    
    # Iterate through all nodes in the graph
    for node in graph:
        if node not in visited:
            # Start DFS from unvisited nodes
            dfs(node)
    
    # Return the reverse of the topological ordering (to get the correct order)
    return topological_ordering[::-1]

# Example adjacency list representing a directed acyclic graph (DAG)
adjacency_list = {
    'v1': ['v7', 'v5', 'v4'],
    'v2': ['v6', 'v5', 'v3'],
    'v3': ['v4', 'v5'],
    'v4': ['v5', 'v7'],
    'v5': ['v7', 'v6'],
    'v6': ['v7'],
    'v7': []
}

# Call the topological_sort function to get the topological ordering
topological_order = topological_sort(adjacency_list)

# Print the topological ordering
print(topological_order)
