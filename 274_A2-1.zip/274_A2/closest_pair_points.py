import random
import math
from collections import defaultdict

def euclidean_distance(point1, point2, points_dict):
    distance = math.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2)
    points_dict[distance] = (point1, point2)
    return distance, points_dict

def brute_force_closest_pair(points, points_dict):
    n = len(points)
    min_distance = float('inf')

    for i in range(n - 1):
        for j in range(i + 1, n):
            distance, points_dict = euclidean_distance(points[i], points[j], points_dict)
            if distance < min_distance:
                min_distance = distance
                
    return min_distance, points_dict

def closest_pair_divide_conquer(points, points_dict):
    n = len(points)

    if n <= 3:
        return brute_force_closest_pair(points, points_dict)

    sorted_points = sorted(points, key=lambda x: x[0])
    mid = n // 2
    mid_x = sorted_points[mid][0]

    left_half = sorted_points[:mid]
    right_half = sorted_points[mid:]

    left_min, points_dict = closest_pair_divide_conquer(left_half, points_dict)
    right_min, points_dict = closest_pair_divide_conquer(right_half, points_dict)

    min_distance = min(left_min, right_min)

    strip = [point for point in sorted_points if (abs(point[0]) - mid_x) < int(min_distance)]

    for i in range(len(strip)):
        for j in range(i + 1, min(i + 7, len(strip))):
            distance, points_dict = euclidean_distance(strip[i], strip[j], points_dict)
            min_distance = min(min_distance, distance)

    return min_distance, points_dict

# Generate 20 random points in the range (0,0) to (40,40)
random.seed(0)
points = [[random.randint(0, 40), random.randint(0, 40)] for _ in range(20)]
print(f"The set of points are {points}.")
points_dict = defaultdict()

# Find the closest pair of points
closest_distance, dictionary = closest_pair_divide_conquer(points, points_dict)
print(f"Closet pair of points is {dictionary[closest_distance]}.")
print("Closest pair distance is ", closest_distance)