def sequence_alignment(seq1, seq2, mismatch_cost, gap_cost):
    m = len(seq1)
    n = len(seq2)

    # Create a matrix to store the alignment costs
    ac = [[0] * (n + 1) for _ in range(m + 1)]

    # Initialize the first row and column with gap costs
    for i in range(m + 1):
        ac[i][0] = i * gap_cost
    for j in range(n + 1):
        ac[0][j] = j * gap_cost

    # Fill the matrix using dynamic programming
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            cost = mismatch_cost if seq1[i - 1] != seq2[j - 1] else 0
            ac[i][j] = min(
                ac[i - 1][j - 1] + cost,  # Match or mismatch
                ac[i - 1][j] + gap_cost,   # Gap in sequence1
                ac[i][j - 1] + gap_cost,   # Gap in sequence2
            )
            
    for i in ac:
        print(i)

    # Backtrack to find the aligned sequences
    aligned_seq1 = []
    aligned_seq2 = []
    i, j = m, n
    while i > 0 and j > 0:
        if ac[i][j] == ac[i - 1][j - 1] + (mismatch_cost if seq1[i - 1] != seq2[j - 1] else 0):
            aligned_seq1.append(" " + seq1[i - 1] + " ")
            aligned_seq2.append(" " + seq2[j - 1] + " ")
            i -= 1
            j -= 1
        elif ac[i][j] == ac[i - 1][j] + gap_cost:
            aligned_seq1.append(" " + seq1[i - 1] + " ")
            aligned_seq2.append(" - ")
            i -= 1
        else:
            aligned_seq1.append(" - ")
            aligned_seq2.append(" " + seq2[j - 1] + " ")
            j -= 1

    while i > 0:
        aligned_seq1.append(" " + seq1[i - 1] + " ")
        aligned_seq2.append(" - ")
        i -= 1

    while j > 0:
        aligned_seq1.append("-")
        aligned_seq2.append(seq2[j - 1])
        j -= 1

    return "".join(reversed(aligned_seq1)), "".join(reversed(aligned_seq2)), ac[m][n]

# Case 1: Mismatch cost = 2, Gap cost = 3
seq2 = "aabbccdd"
seq1 = "aabcbccdcd"

mismatch_cost = 2
gap_cost = 3

mismatch_cost2 = 6
gap_cost2 = 2

aligned_seq1, aligned_seq2, minimum_cost = sequence_alignment(seq1, seq2, mismatch_cost, gap_cost)
print("Minimum Cost Sequence Alignment:")
print("Sequence 1:", aligned_seq1)
print("Sequence 2:", aligned_seq2)
print("Minimum Cost:", minimum_cost)

aligned_seq1, aligned_seq2, minimum_cost = sequence_alignment(seq1, seq2, mismatch_cost2, gap_cost2)
print("Minimum Cost Sequence Alignment:")
print("Sequence 1:", aligned_seq1)
print("Sequence 2:", aligned_seq2)
print("Minimum Cost:", minimum_cost)