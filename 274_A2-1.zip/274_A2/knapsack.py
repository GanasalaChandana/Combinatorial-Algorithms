# Define a function to solve the knapsack problem with item names, values, and weights
def knapsack(items, cap):
    n = len(items)  # Number of items
    t = [[0] * (cap + 1) for _ in range(n + 1)]  # Create a 2D table for dynamic programming

    # Create a table to keep track of selected items
    selected = [[False] * (cap + 1) for _ in range(n + 1)]

    # Iterate through rows (items)
    for i in range(n + 1):
        # Iterate through columns (knapsack capacities)
        for w in range(cap + 1):
            if i == 0 or w == 0:
                t[i][w] = 0  # Initialize the first row and column to 0
            elif items[i - 1][2] <= w:
                wo_current_item = t[i - 1][w]
                wi_current_item = items[i - 1][1] + t[i - 1][w - items[i - 1][2]]

                # Select the item if it contributes to a higher value
                if wi_current_item > wo_current_item:
                    t[i][w] = wi_current_item
                    selected[i][w] = True
                else:
                    t[i][w] = wo_current_item
            else:
                t[i][w] = t[i - 1][w]

    selected_items = []  # Initialize a list to store the selected items
    i, w = n, cap  # Start from the last item and the maximum capacity

    # Trace back to identify the selected items
    while i > 0 and w > 0:
        if selected[i][w]:
            selected_items.append(items[i - 1][0])  # Append the name of the selected item
            w -= items[i - 1][2]  # Reduce the remaining capacity by the weight of the selected item
        i -= 1  # Move to the previous item

    return t[n][cap], selected_items  # Return the maximum value and the list of selected items

# List of items with their names, values, and weights
items = [("A", 2, 10), ("B", 10, 8), ("C", 14, 7), ("D", 8, 7), ("E", 10, 6)]
cap = 30  # Knapsack capacity

# Call the knapsack_with_items function to calculate the maximum value and selected items
max_value, selected_items = knapsack(items, cap)

# Print the results
print("Maximum value:", max_value)
print("Selected items:", selected_items)
