import bisect

#Function to compute the previous interval for each task

def previous_interval(I):
    p = []  #List to store the index of the previous interval for each task  
#the time complexity for this step is  O(nlogn)
    start = [task[0] for task in I]
    finish = [task[1] for task in I]
    for i in range(len(I)):
#use binary search to find the index of the previous Interval
        idx = bisect.bisect(finish, start[i]) - 1
        p.append(idx)

    return p

#Function to find the solution by Backtracking 
#Time complexity for backtracking is O(n)

def find_solution(j):
    #backtracking : recursively find the solution by considering the optimal intervals
    if j == -1:
        return
    
    else:
        if(I[j][2] + OPT[p[j]]) >= OPT[j-1]:
            O.append(I[j])
            find_solution(p[j])

        else:
            find_solution(j-1)

#Function to compute the optimal solution using dynamic programming
#The worst time complexity here in this function is O(n^2)

def compute_opt(j):
    #use recursive formula max(wj + OPT(p(j)), OPT(j-1))
    if j == -1:
        return 0
    
    elif(0 <= j) and (j < len(OPT)):
        return OPT[j]
    
    else:
        return max(I[j][2] + compute_opt(p[j]), compute_opt(j-1))

#Function to solve the weighted Interval Scheduling problem

def weighted_Interval(I):
    for j in range(len(I)):
        opt_j = compute_opt(j)
        OPT.append(opt_j)
    find_solution(len(I) - 1)
    return OPT[-1]
    
    
if __name__ == '__main__':
    #OPT for optimal weight, 0 for best jobs to pick
    OPT = []
    O = []

    #Define the Intervals(tasks) are labeled as : (start,end,weight)
    t1 = (1,4,5)
    t2 = (3,7,4)
    t3 = (3,5,6)
    t4 = (5,9,7)
    t5 = (6,9,6)

I = [t1,t2,t3,t4,t5]

#Sort the intervals by the end time for compatibility with the algorithm
I.sort(key = lambda tup : tup[1])

#Compute the index of the previous interval for each task
p = previous_interval(I)

#Find the Optimal solution and print the result
opt_sol = weighted_Interval(I)
print('Maximum weight:' + str(opt_sol))
print('The best jobs to take are: ' + str(O[::-1]))